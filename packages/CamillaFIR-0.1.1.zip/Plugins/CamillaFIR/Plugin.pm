package Plugins::CamillaFIR::Plugin;
use strict;
use base qw(Slim::Plugin::Base);

sub getDisplayName { 'CamillaFIR DSP' }

1;
