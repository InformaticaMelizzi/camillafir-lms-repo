package Plugins::CamillaFIR::Plugin;
use strict;
our $VERSION = '0.1';
sub initPlugin { 1 }
sub getDisplayName { 'CamillaFIR DSP' }
1;
