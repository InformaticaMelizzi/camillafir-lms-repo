package Plugins::CamillaFIR::Plugin;

use strict;
use base qw(Slim::Plugin::Base);

sub getDisplayName {
    return 'CamillaFIR DSP';
}

1;
