package Plugins::CamillaFIR::Plugin;

use strict;
use warnings;

use base qw(Slim::Plugin::Base);

sub getDisplayName {
    return 'CamillaFIR DSP';
}

1;
