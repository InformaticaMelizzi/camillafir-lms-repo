package Plugins::CamillaFIR::Plugin;

use strict;
use warnings;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Log;

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.camillafir',
    'defaultLevel' => 'INFO',
    'description'  => 'PLUGIN_CAMILLAFIR',
});

sub getDisplayName {
    return 'CamillaFIR DSP';
}

sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin();
    
    $log->info("CamillaFIR DSP plugin version 0.1.3 initialized");
}

1;

__END__
